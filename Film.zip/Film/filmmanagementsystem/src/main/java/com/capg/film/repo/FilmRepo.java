package com.capg.film.repo;

import java.util.Date;
import java.util.List;

import com.capg.film.pojo.Film;

public interface FilmRepo {
	public Film save(Film film);
	public List<Film> findFilmByTitle(String title);
	public List<Film> findFilmByLanguage(String language);
	public List<Film> findFilmByRating(byte rating);
	public List<Film> findFilmByReleaseYear(Date releaseyear);
	public  boolean remove(String title);
	public boolean updateFilm(Film film);
	
	}

