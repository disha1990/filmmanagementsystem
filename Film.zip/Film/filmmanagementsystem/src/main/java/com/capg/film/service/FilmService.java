package com.capg.film.service;

import java.util.Date;
import java.util.List;

import com.capg.film.pojo.Actor;
import com.capg.film.pojo.Album;
import com.capg.film.pojo.Category;
import com.capg.film.pojo.Film;

public interface FilmService {
	public Film createFilm(Film film);
	public List<Film> findFilmByTitle(String title);
	public List<Film> findFilmByLanguage(String language);
	public List<Film> findFilmByRating(byte rating);
	public List<Film> findFilmByReleaseYear(Date releaseyear);
	public String deleteFilm(String title);
	public String modifyFilm(Film film);
}
